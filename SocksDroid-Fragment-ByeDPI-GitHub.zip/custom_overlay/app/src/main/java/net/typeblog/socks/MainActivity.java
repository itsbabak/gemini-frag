package net.typeblog.socks;

import android.content.Intent;
import android.content.SharedPreferences;
import android.net.VpnService;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private static final String PREFS_NAME = "FragmentVpnPrefs";
    private static final String KEY_JSON = "saved_json";

    private static final String DEFAULT_JSON = "{\n" +
            "  \"inbounds\": [{\"port\": 10808, \"listen\": \"127.0.0.1\", \"protocol\": \"socks\"}],\n" +
            "  \"outbounds\": [{\n" +
            "    \"tag\": \"fragment-out\",\n" +
            "    \"protocol\": \"freedom\",\n" +
            "    \"settings\": {\n" +
            "      \"fragment\": {\"packets\": \"tlshello\", \"length\": \"10-400\", \"interval\": \"1-30\"}\n" +
            "    }\n" +
            "  }]\n" +
            "}";

    private EditText etJsonConfig;
    private Button btnToggle;
    private boolean isRunning = false;

    private final ActivityResultLauncher<Intent> vpnPermissionLauncher =
            registerForActivityResult(new ActivityResultContracts.StartActivityForResult(), result -> {
                if (result.getResultCode() == RESULT_OK) {
                    startVpnService();
                } else {
                    Toast.makeText(this, "مجوز VPN داده نشد", Toast.LENGTH_SHORT).show();
                }
            });

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        etJsonConfig = findViewById(R.id.et_json_config);
        btnToggle = findViewById(R.id.btn_toggle_vpn);

        SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        etJsonConfig.setText(prefs.getString(KEY_JSON, DEFAULT_JSON));

        btnToggle.setOnClickListener(v -> {
            if (!isRunning) {
                String json = etJsonConfig.getText().toString().trim();
                prefs.edit().putString(KEY_JSON, json).apply();

                Intent intent = VpnService.prepare(this);
                if (intent != null) {
                    vpnPermissionLauncher.launch(intent);
                } else {
                    startVpnService();
                }
            } else {
                stopVpnService();
            }
        });
    }

    private void startVpnService() {
        String json = etJsonConfig.getText().toString().trim();
        Intent intent = new Intent(this, SocksVpnService.class);
        intent.putExtra("JSON_CONFIG", json);
        startForegroundService(intent);
        isRunning = true;
        btnToggle.setText("قطع اتصال (Disconnect)");
    }

    private void stopVpnService() {
        Intent intent = new Intent(this, SocksVpnService.class);
        intent.setAction("STOP_VPN");
        startService(intent);
        isRunning = false;
        btnToggle.setText("اتصال (Connect)");
    }
}
