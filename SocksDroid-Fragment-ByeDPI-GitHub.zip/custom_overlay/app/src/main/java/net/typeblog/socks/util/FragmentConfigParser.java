package net.typeblog.socks.util;

import org.json.JSONArray;
import org.json.JSONObject;
import java.util.ArrayList;
import java.util.List;

public class FragmentConfigParser {

    public static class ParsedConfig {
        public int localPort = 10808;
        public String dnsServer = "1.1.1.1";
        public List<String> byeDpiArgs = new ArrayList<>();
    }

    public static ParsedConfig parse(String jsonString) {
        ParsedConfig result = new ParsedConfig();
        try {
            JSONObject root = new JSONObject(jsonString);

            if (root.has("inbounds")) {
                JSONArray inbounds = root.getJSONArray("inbounds");
                if (inbounds.length() > 0) {
                    result.localPort = inbounds.getJSONObject(0).optInt("port", 10808);
                }
            }

            result.byeDpiArgs.add("-i");
            result.byeDpiArgs.add("127.0.0.1");
            result.byeDpiArgs.add("-p");
            result.byeDpiArgs.add(String.valueOf(result.localPort));

            int splitPos = 2;
            if (root.has("outbounds")) {
                JSONArray outbounds = root.getJSONArray("outbounds");
                for (int i = 0; i < outbounds.length(); i++) {
                    JSONObject ob = outbounds.getJSONObject(i);
                    if (ob.has("settings") && ob.getJSONObject("settings").has("fragment")) {
                        JSONObject frag = ob.getJSONObject("settings").getJSONObject("fragment");
                        String length = frag.optString("length", "10-400");
                        if (length.contains("-")) {
                            splitPos = Integer.parseInt(length.split("-")[0].trim());
                        }
                        break;
                    }
                }
            }

            result.byeDpiArgs.add("-s");
            result.byeDpiArgs.add(String.valueOf(Math.max(1, splitPos)));
            result.byeDpiArgs.add("-o");
            result.byeDpiArgs.add("1");
            result.byeDpiArgs.add("-r");
            result.byeDpiArgs.add("1+s");

        } catch (Exception e) {
            result.byeDpiArgs.clear();
            result.byeDpiArgs.add("-i");
            result.byeDpiArgs.add("127.0.0.1");
            result.byeDpiArgs.add("-p");
            result.byeDpiArgs.add("10808");
            result.byeDpiArgs.add("-s");
            result.byeDpiArgs.add("2");
            result.byeDpiArgs.add("-o");
            result.byeDpiArgs.add("1");
        }
        return result;
    }
}
