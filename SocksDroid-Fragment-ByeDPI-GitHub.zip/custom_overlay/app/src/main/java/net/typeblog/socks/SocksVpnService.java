package net.typeblog.socks;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.content.Intent;
import android.net.VpnService;
import android.os.Build;
import android.os.ParcelFileDescriptor;
import net.typeblog.socks.util.FragmentConfigParser;
import net.typeblog.socks.util.Utility;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

public class SocksVpnService extends VpnService {

    private ParcelFileDescriptor vpnInterface;
    private Process byeDpiProcess;
    private static final String CHANNEL_ID = "FragmentVpnChannel";

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null && "STOP_VPN".equals(intent.getAction())) {
            stopVpn();
            stopSelf();
            return START_NOT_STICKY;
        }

        createNotificationChannel();
        Notification notification = new Notification.Builder(this, CHANNEL_ID)
                .setContentTitle("Fragment VPN")
                .setContentText("متصل با موتور سبک ByeDPI")
                .setSmallIcon(android.R.drawable.ic_dialog_info)
                .build();
        startForeground(1, notification);

        String jsonConfig = intent != null ? intent.getStringExtra("JSON_CONFIG") : "";
        FragmentConfigParser.ParsedConfig config = FragmentConfigParser.parse(jsonConfig);

        startByeDpi(config);
        startTun2Socks(config.localPort);

        return START_STICKY;
    }

    private void startByeDpi(FragmentConfigParser.ParsedConfig config) {
        try {
            stopByeDpi();
            String binPath = getApplicationInfo().nativeLibraryDir + "/libciadpi.so";
            File binFile = new File(binPath);
            if (!binFile.exists()) return;

            List<String> cmd = new ArrayList<>();
            cmd.add(binPath);
            cmd.addAll(config.byeDpiArgs);

            ProcessBuilder pb = new ProcessBuilder(cmd);
            pb.redirectErrorStream(true);
            byeDpiProcess = pb.start();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void startTun2Socks(int socksPort) {
        try {
            Builder builder = new Builder();
            builder.setSession("FragmentVPN");
            builder.setMtu(1500);
            builder.addAddress("10.0.0.2", 24);
            builder.addRoute("0.0.0.0", 0);
            builder.addDnsServer("1.1.1.1");
            builder.addDisallowedApplication(getPackageName());

            vpnInterface = builder.establish();
            if (vpnInterface != null) {
                int fd = vpnInterface.getFd();
                Utility.startVpn(fd, "10.0.0.2", "255.255.255.0", "127.0.0.1", socksPort, "1.1.1.1", 1500);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void stopByeDpi() {
        if (byeDpiProcess != null) {
            byeDpiProcess.destroy();
            byeDpiProcess = null;
        }
    }

    private void stopVpn() {
        stopByeDpi();
        try {
            Utility.stopVpn();
            if (vpnInterface != null) {
                vpnInterface.close();
                vpnInterface = null;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    public void onDestroy() {
        stopVpn();
        super.onDestroy();
    }

    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(
                    CHANNEL_ID, "Fragment VPN Service", NotificationManager.IMPORTANCE_LOW);
            NotificationManager manager = getSystemService(NotificationManager.class);
            if (manager != null) {
                manager.createNotificationChannel(channel);
            }
        }
    }
}
